# Simple-VideoPlayer-Channel Example
![Roku](https://img.shields.io/badge/Roku-Dev-blue.svg)

SimpleVideoPlayer Sample Channel for the Roku Platform.

## Use case
This sample channel can be used for testing video stream of a particular content.

## How to run this sample
- Zip up the entire project directory and deploy to your roku device. Follow the developer set-up guide here for a quick guide on how to do so: https://blog.roku.com/developer/2016/02/04/developer-setup-guide/
- Alternatively, open up this project in Eclipse or Atom and use the corresponding plugin/package to export/deploy the channel.
  - Roku Deploy package for Atom: https://atom.io/packages/roku-deploy
- DeepLink the contentID to the app

## Features
- If no contentID has deep linked simply opening the channel will play the hardcoded stream

## Directory Structure
- **Components:** The Scene Graph components
  - **Task.xml** A task node that is used to exit the channel on buttonpress.
  - **DRMTokenFetcher.xml** A task node that is used to fetch the stream details of the content that is associated with the contentID.
  - **SimpleVideoScene.brs/xml:** The main scene.
- **Images:** Contains image assets used in the channel
- **Source:** Contains the main brightscript file that runs right when the channel starts
